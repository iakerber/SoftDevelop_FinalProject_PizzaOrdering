'''
This is the Pizza Ordering App as far as I have gotten
Ilze Akerbergs, Mar 06, 2024, final improvements Mar 08, 2024
Software Development - Final Project - Module 8
'''



'''importing tkinter and Pillow modules'''
import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image, ImageFont, ImageDraw



'''Create the main program, the root Window'''
root = tk.Tk()

#create the title which shows up in the tab of the window
root.title('Pizza Ordering')

#set the window size
root.geometry('640x580+300+300')
root.resizable(False, False)

#change the window background color by configuring root window
root.config(bg = 'light blue')



'''MAIN WIDGETS'''
''' These are the program widgets'''
#label main
title = tk.Label(root, text = ('Order your pizzas here'), font="Verdana 16 bold", bg = '#E8EBD2', fg = '#000099')

#define name string variables for input of user name, with label and input field
nameVar = tk.StringVar(root) #variable for name of user
nameLabel = tk.Label(root, text = 'Input your name here for ordering: ') #label for name input
nameInput = tk.Entry(root, textvariable = nameVar) #entry field for name input

#define boolean variable for repeat customers 
repeatVar = tk.BooleanVar() #variable boolean to show if repeat customer
repeatInput = tk.Checkbutton(root, variable = repeatVar, text = 'Check if you are a repeat customer') #input check box

#create a spinbox to find out how many pizzas in the order
numVar = tk.IntVar(value = 4) #how many pizzas ordered
numLabel = tk.Label(text = 'How many pizzas do you want to order?') #label for number of pizzas
numInput = tk.Spinbox(root, textvariable = numVar, from_= 0, to = 6, increment = 1) #input spinbox for number

#listbox for the types of pizzas
pizzaVar = tk.StringVar(value = '') #choice of pizzas in variable
pizzaLabel = tk.Label(root, text = 'What pizza would you like to order?') #label for pizza choices
pizzaChoices = ('', 'Any', 'Pepperoni', 'Vegetarian', 'Cheese', 'Everything on it') #actual pizza choices in list
pizzaInput = tk.OptionMenu(root, pizzaVar, *pizzaChoices) #input for choices

#radiobutton to find out if they want to purchase anything extra
extrasLabel = tk.Label(root, text = 'Do you wish to purchase anything from our extras menu?') #label for extras boolean
extrasFrame = tk.Frame(root) #frame for whole extras sub
extrasVar = tk.BooleanVar() #boolean for yes/no if desire extras
extrasYesInput = tk.Radiobutton(extrasFrame, text = 'Yes, please', value = True, variable = extrasVar) #yes result
extrasNoInput = tk.Radiobutton(extrasFrame, text = 'No, thank you', value = False, variable = extrasVar) #no result



'''OPENING SECOND WINDOW'''
'''opening a second window, defined by 'top', to show the extras, defined by openExtras() function
In this window one can choose an extra. Through the global extraChoiceVar, the extra choice will show up in root'''
def openExtras():
    
    top = tk.Toplevel()
    top.title('Choose extras')

    #listbox for extras, with global extraChoiceVar that will transfer choice to root window.
    global extraChoiceVar # variable that will carry extras choice to root window
    extraChoiceVar = tk.StringVar(value = 'Breadstick')
    extraLabel = tk.Label(top, text = 'What extra would you like to order?')
    extraChoices = ('Breadstick', 'Onion rings', 'Cookie', 'Extra cheese', 'Soft drink')
    extraInput = tk.OptionMenu(top, extraChoiceVar, *extraChoices)

    #window geometry
    extraLabel.pack(side = 'left', ipadx = 20, ipady = 5)
    extraInput.pack(side = 'left', ipadx = 20, ipady = 5)

    #button to close window
    closeExtrasButton = tk.Button(top, text='Close window', command=top.destroy)
    closeExtrasButton.pack(side = 'left', ipadx = 20, ipady = 5)



'''Additional buttons on root'''
#button to open the Extras window and the function openExtras()
extrasButton = tk.Button(root, text='Choose extras here', command=openExtras)
extrasButton.grid(row = 8, columnspan = 2, sticky = tk.W)

#exit button to close root app
closeButton = tk.Button(root, text='Quit pizza app', command=root.destroy)
closeButton.grid(row = 20, columnspan = 2, sticky = 'W')

#function to clear name field and order summary. Couldn't get the pizza choices to clear with blank field
def clear():
    outputVar.set("")
    nameVar.set("")

#clear button for reset
clearButton = tk.Button(root, text='Clear order', command=clear)
clearButton.grid(row = 20, column = 2, sticky = 'W')

#submit order
submitBtn = tk.Button(root, text = 'Submit your order')

#writes the final string output 
outputVar = tk.StringVar(value = '')
outputLine = tk.Label(root, textvariable = outputVar, anchor = 'w', justify = 'left')



'''MAIN GEOMETRY'''
'''geometry of objects inside the main window'''
#title objects on grid
title.grid(row = 0, columnspan = 3)
nameLabel.grid(row = 1, column = 0)
nameInput.grid(row = 1, column = 1)

#checkbox grid for repeat customer
repeatInput.grid(row = 2, column = 1, columnspan = 2)

#spinbox grid for how many pizzas to order
numLabel.grid(row = 3, sticky = tk.W)
numInput.grid(row = 3, column = 1)

#padx and pady for pizza list
pizzaLabel.grid(row = 4, columnspan = 2, sticky = tk.W, pady = 10)
pizzaInput.grid(row = 4, column = 1, padx = 25, pady = 10)

#shove the extras radiobox onto the screen
extrasYesInput.pack(side = 'left', fill = 'x', ipadx = 10, ipady = 5)
extrasNoInput.pack(side = 'left', fill = 'x', ipadx = 10, ipady = 5)
extrasLabel.grid(row = 6, columnspan = 2, sticky = tk.W)
extrasFrame.grid(row = 7, columnspan = 2, sticky = tk.W)

#submit button grid to appear close to the bottom of the window
submitBtn.grid(row = 99)
outputLine.grid(row = 100, columnspan = 3, sticky = 'NSEW')



'''IMAGES MODULE'''
'''button functions to bring up quick links to choose the two favorite pizzas, pepperoni and vegetarian'''
'''label for advertising quick links to the two favorite pizza types'''
favoritePizzaLabel = tk.Label(root, text="Quick links to our two best-selling pizzas")
favoritePizzaLabel.grid(row = 21, columnspan = 2, sticky = 'W')
def pepperoniQuick():
    pizzaVar.set('Pepperoni')

def vegetarianQuick():
    pizzaVar.set('Vegetarian')


'''insert images as buttons and their captions. These images are clickable and bring up above Quick functions'''
#images opened and placed
my_img = ImageTk.PhotoImage(Image.open("Freshly_baked_pizza-4_small.jpg")) #image 1
my_img_Button = tk.Button(image=my_img, command=pepperoniQuick) #button for image 1
my_img2 = ImageTk.PhotoImage(Image.open("Another_pizza_small.jpg")) #image 2
my_img2_Button = tk.Button(image=my_img2, command=vegetarianQuick) #button for image 2

#text labels for images
img_label = tk.Label(root, text="Pepperoni pizza") #caption for image 1
img2_label = tk.Label(root, text="Vegetarian pizza") #caption for image 2


'''geometry of image objects'''
my_img_Button.grid(row = 22, column = 0, sticky = 'W')
my_img2_Button.grid(row = 22, column = 1, sticky = 'W')
img_label.grid(row = 23, column = 0, sticky = 'W')
img2_label.grid(row = 23, column = 1, sticky = 'W')



'''PRICES'''
'''price list for pizza and extras in a static label'''
pricePizza_label = tk.Label(root, text="Regular pizza costs $10.00.\n Extras food price is $5.00") #label for pizza prices
pricePizza_label.grid(row = 22, column = 2)

#static variables for prices
pricePizzaVar = tk.DoubleVar(value = 10.00) #price for a pizza
priceExtraVar = tk.DoubleVar(value = 5.00) #price for an extra


'''configuring columns and rows'''
#columnconfigure
root.columnconfigure(1, weight = 1)

#rowconfigure
root.rowconfigure(99, weight = 2)
root.rowconfigure(100, weight = 1)


'''SUBMIT'''
'''function for the submit button'''
def on_submit():
    #what happens when the user presses submit
    #Vars all use 'get()' in order to access values for the variables
    name = nameVar.get() #name that user input
    
    #input validation: check if input is empty and show error if it is empty.Messagebox was tkinter import
    if len(name) == 0:
        messagebox.showerror('Error', 'Name entry is empty. Please enter your name')
    else:
        pass

    #try-except for input validation for an integer input
    try:
        number = numVar.get()
    except tk.TclError:
        number = 10000

    #giving local variables to the fetched variable values
    pizzas = pizzaVar.get()
    
    #error if no pizza chosen, couldn't figure out how to get final output to not show up on pressing OK
    if pizzaVar.get()=='':
        
        messagebox.showerror("Error", "Please choose a pizza from the dropdown box")
        

    #get the repeat customer and extras Boolean variables
    repeat = repeatVar.get()
    extras = extrasVar.get()
    
    #if Boolean radiobutton for extras was chosen as 'yes', then get the extra that was chosen in the other extras window
    if extras:
        extraChoice = extraChoiceVar.get()


    '''FINAL MESSAGES OUTPUT'''
    '''output messages that appear at the bottom of the window'''
    message = f'Here is the total sum and a summary of your order, {name}.\n'

    #check if user checked the repeat customer box
    if not repeat:
        message += f'Welcome to our wonderful pizza store. Enjoy your {number} {pizzas} pizzas!\n'
    else:
        message += f'Welcome back, {name}. We appreciate your business. Enjoy your {number} {pizzas} pizzas!\n'

    #check if user has checked the extras radio box
    if extras:
        message += 'Thank you for ordering extras.\n'
        #if an extraChoice was chosen, message reflects the extras choice
        if extraChoice:
            message += f'Your order includes a {extraChoice}!\n'
    else:
        message += 'It is OK not to get any extras. Pizzas alone it is.\n'


    '''ORDER COMPUTATIONS'''
    '''compute sum of order. Fetching the values for the variable and include the result in a message'''
    pricePizza = pricePizzaVar.get()
    priceExtra = priceExtraVar.get()
    sumOrder = number * pricePizza
    #check if check box for extras is checked
    if extras:
        #if so, check which extra was chosen
        if extraChoice:
            sumOrder += priceExtra
    message += f'Total sum of order is ${sumOrder:.2f}.\n'

    #outputting the messages
    outputVar.set(message)

'''calling the submit button and running the program'''
submitBtn.configure(command = on_submit)

root.mainloop()
